package dev.cart3r.tv

import android.app.Activity
import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Ink = Color(0xFF090909)
private val Panel = Color(0xFF191919)
private val Red = Color(0xFFFF3434)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Ink, surface = Panel)) { TvHome(this) } }
    }
}

data class TvDevice(val name: String, val host: String?, val port: Int)

@Composable
private fun TvHome(context: Context) {
    var devices by remember { mutableStateOf<List<TvDevice>>(emptyList()) }
    var chosen by remember { mutableStateOf<TvDevice?>(null) }
    var scanning by remember { mutableStateOf(false) }
    val discovery = remember { TvDiscovery(context) }

    DisposableEffect(Unit) {
        discovery.onDevice = { found -> devices = (devices + found).distinctBy { it.name + it.host } }
        onDispose { discovery.stop() }
    }
    Column(Modifier.fillMaxSize().background(Ink).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("CART3R TV", style = MaterialTheme.typography.headlineMedium, color = Red)
        Text("Local network remote", color = Color.LightGray)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("DEVICES ON YOUR WI-FI", color = Red)
                Button(onClick = { devices = emptyList(); scanning = true; discovery.start { scanning = false } }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (scanning) "Scanning…" else "Scan network")
                }
                if (devices.isEmpty()) Text("Tap Scan network. TV and phone must share the same Wi-Fi.", color = Color.Gray)
                LazyColumn(Modifier.heightIn(max = 250.dp)) {
                    items(devices) { tv ->
                        Row(Modifier.fillMaxWidth().clickable { chosen = tv }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(tv.name); Text(tv.host?.hostAddress ?: "Discovered device", color = Color.Gray) }
                            RadioButton(chosen == tv, onClick = { chosen = tv })
                        }
                    }
                }
            }
        }
        chosen?.let { tv ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("SELECTED TV", color = Red)
                    Text(tv.name, style = MaterialTheme.typography.titleLarge)
                    Text("Pairing and remote protocol are not wired into this starter build.", color = Color.LightGray)
                    Text("Next integration: Android TV Remote v2 TLS pairing + key messages.", color = Color.Gray)
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("AD / TRACKER FILTER", color = Red)
                Text("Network filtering is a separate opt-in VPN feature. DNS filtering may block trackers, but cannot reliably remove YouTube ads without also risking video playback.", color = Color.LightGray)
            }
        }
    }
}

/** Discovers the Android TV Remote v2 advertised mDNS service. */
class TvDiscovery(context: Context) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var listener: NsdManager.DiscoveryListener? = null
    var onDevice: ((TvDevice) -> Unit)? = null

    fun start(onFinished: () -> Unit = {}) {
        stop()
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onServiceFound(service: NsdServiceInfo) {
                if (service.serviceType.contains("androidtvremote2", ignoreCase = true)) {
                    nsd.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(si: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(si: NsdServiceInfo) {
                            onDevice?.invoke(TvDevice(si.serviceName, si.host, si.port))
                        }
                    })
                }
            }
            override fun onServiceLost(service: NsdServiceInfo) {}
            override fun onDiscoveryStopped(serviceType: String) { onFinished() }
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { stop(); onFinished() }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) { stop() }
        }
        listener = l
        nsd.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, l)
    }
    fun stop() { listener?.let { runCatching { nsd.stopServiceDiscovery(it) } }; listener = null }
}
