# CART3R TV — Android starter

A small Kotlin + Jetpack Compose project scaffold for local Android TV discovery.

## Open/build
1. Install Android Studio and JDK 17.
2. Open this directory in Android Studio and allow Gradle sync.
3. Run on an Android phone (API 26+); accept local-network permissions if prompted by your OS.

## Included
- Dark crimson minimal Compose UI
- mDNS discovery of `_androidtvremote2._tcp.` devices via `NsdManager`
- Device selection state
- Basic feature/architecture notes

## Not yet implemented (required for a production complete app)
- TV Remote v2 protobuf message definitions and length-delimited framing
- Secure TLS client-certificate pairing and PIN/code UI
- Persisted TV certificate and reconnect logic
- Keypress / text input / media control messages
- Optional, correctly implemented DNS VPN packet forwarding and user-consent flow

The remote protocol is device/service-version sensitive. Integrate and test a maintained protocol implementation rather than sending guessed raw socket commands. A reference project: https://github.com/theharisshah/androidremote

## Ad blocking note
The app does not claim to remove YouTube in-stream ads. DNS filtering is suitable for known tracker/ad hostnames but YouTube ad delivery often shares infrastructure with content. A full Android `VpnService` must implement packet forwarding correctly; a DNS-only TUN stub would break internet access and is intentionally not included.
